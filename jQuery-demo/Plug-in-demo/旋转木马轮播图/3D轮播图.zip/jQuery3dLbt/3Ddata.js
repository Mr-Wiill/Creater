//自己创建一个数据
var data = {
	letv:[
		{
			"ul":"#",
			"title":"Picture information1",
			"date":"2017.02.01日 11:30",
			"id":11,
			"name":"张三",
			"img":"img/01.png"
		},		
		{
			"ul":"#",
			"title":"Picture information2",
			"date":"2017.02.01日 11:30",
			"id":12,
			"name":"张三",
			"img":"img/02.png"
		},			
		{
			"ul":"#",
			"title":"Picture information3",
			"date":"2017.02.03日 11:30",
			"id":13,
			"img":" img/03.png"
		},
		{
			"ul":"#",
			"title":"Picture information4",
			"date":"2017.02.04日 11:30",
			"id":14,
			"img":" img/04.png"
		},
		{
			"ul":"#",
			"title":"Picture information5",
			"date":"2017.02.05日 11:30",
			"id":15,
			"img":" img/05.png"
		},
		{
			"ul":"#",
			"title":"Picture information6",
			"date":"2017.05.06日 11:30",
			"id":16,
			"img":" img/06.png"
		},
		{
			"ul":"#",
			"title":"Picture information7",
			"date":"2017.04.07日 11:30",
			"id":17,
			"img":" img/07.png"
			
		},
	
	]
}